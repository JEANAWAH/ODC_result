// Restaurant data
// const restaurants = [
//   {
//     image: "largege.jpeg",
//     name: "L'Arpège",
//     cuisine: "French, African, Italian, European",
//   },
//   {
//     image: "clameto.jpeg",
//     name: "Clamato",
//     cuisine: "French, Cafe",
//   },
//   {
//     image: "grandvefour.jpeg",
//     name: "Le Grand Véfour",
//     cuisine: "French, Fine Dining",
//   },
//   {
//     image: "lespavillion.jpeg",
//     name: "Les Pavillons des Berges",
//     cuisine: "French, Contemporary",
//   },
//   {
//     image: "lemaximet.jpeg",
//     name: "Le Maximin",
//     cuisine: "French, Mediterranean",
//   },
//   {
//     image: "lepredicateur.jpeg",
//     name: "Le Prédicateur",
//     cuisine: "French, Bistro",
//   },
// ];

const restaurants = [];
const searchInput = document.getElementById("search-input");//get search element
const restaurantGrid = document.getElementById("restaurant-grid");//get div restauratn grid
const loadingSpinner = document.createElement('div'); //create loading spinner
loadingSpinner.classList.add('loading-spinner');//add class to loading spinner

// Function to fetch restaurant data from the API
async function fetchRestaurantData() {
  const apiUrl =
    "https://opendata.paris.fr/api/explore/v2.1/catalog/datasets/restaurants-casvp/records?limit=8";

  // Use AJAX to make the request
  await fetch(apiUrl)
    .then((response) => response.json())
    .then((data) => {
      console.log(data.results);
      // restaurantsFetch = data.results.filter(result => result.ville === 'PARIS')
      const restaurantsFetch = data.results
        .filter((restaurant) => restaurant.ville === "PARIS")
        .map((restaurant) => ({
          name: restaurant.nom_restaurant,
          cuisine: restaurant.type,
          image: "./img/largege.jpeg", //No Image to retrieve from endpoint since the provide api link is empty
        }));
      console.log(typeof restaurants);
      console.log(typeof restaurantsFetch);
      console.log(restaurantsFetch);
      restaurants.push(...restaurantsFetch);
      console.log(restaurants);

      const restaurantGrid = document.querySelector(".restaurant-grid");

      // Populate the restaurant grid
      restaurants.forEach((restaurant) => {
        const section = createRestaurantSection(restaurant);
        restaurantGrid.appendChild(section);
      });
    })
    .catch((error) => {
      console.error("Error fetching restaurant data:", error);
    });
}

// Call the fetchRestaurantData function when the page loads
window.addEventListener("DOMContentLoaded", fetchRestaurantData);

// Function to create a restaurant section
function createRestaurantSection(restaurant) {
  const section = document.createElement("section");
  section.classList.add("restaurant-section");

  const card = document.createElement("div");
  card.classList.add("restaurant-card");

  const img = document.createElement("img");
  img.src = restaurant.image;
  img.alt = restaurant.name;

  const h2 = document.createElement("h2");
  h2.textContent = restaurant.name;

  const p = document.createElement("p");
  p.textContent = restaurant.cuisine;

  card.appendChild(img);
  card.appendChild(h2);
  card.appendChild(p);
  section.appendChild(card);

  return section;
}

//This is to listen for a search request
searchInput.addEventListener("input", () => {
  const searchParam = searchInput.value.toLowerCase().trim();
  if (searchParam == "s" || searchParam == "e") {
    const filteredRestaurants = searchRestaurants(searchParam);
    console.log(filteredRestaurants);
    displayRestaurants(filteredRestaurants);
  } else {
    window.location.reload();
  }
});

//this function returns all restaurants with specific dish
function searchRestaurants(searchParam) {
  return restaurants.filter((restaurant) => {
    return restaurant.cuisine.toLowerCase() == searchParam.toLowerCase();
  });
}

//this function displays all restaurants with specific dish
function displayRestaurants(restaurants) {
  let restaurantHTML = "";
  restaurants.forEach((restaurant) => {
    restaurantHTML += `
          <section class="restaurant-section">
            <div class="restaurant-card">
            <img src="${restaurant.image}" alt="${restaurant.name}">
              <h3>${restaurant.name}</h3>
              <p>Cuisine: ${restaurant.cuisine}</p>              
            </div>
            </section>
          `;
  });
  restaurantGrid.innerHTML = restaurantHTML;
}

// // Get the restaurant grid element
// const restaurantGrid = document.querySelector(".restaurant-grid");

// // Populate the restaurant grid
// restaurants.forEach((restaurant) => {
//   const section = createRestaurantSection(restaurant);
//   restaurantGrid.appendChild(section);
// });


function showLoadingSpinner() {
  if (restaurantGrid.children.length === 0) {
    restaurantGrid.appendChild(loadingSpinner);
  }
}

function hideLoadingSpinner() {
  if (loadingSpinner.parentNode === restaurantGrid) {
    restaurantGrid.removeChild(loadingSpinner);
  }
}

// Call the showLoadingSpinner function when the page loads or the content updates
window.addEventListener('load', showLoadingSpinner);
restaurantGrid.addEventListener('DOMSubtreeModified', showLoadingSpinner);

// Call the hideLoadingSpinner function when the content is loaded
restaurantGrid.addEventListener('DOMNodeInserted', hideLoadingSpinner);